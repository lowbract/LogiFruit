
<html>
		
<head>
<title>HTML Test</title>
</head>

<body>
    
<form method="post" action="pippo.php">
    <select name="website_string"> 
        <option value="" selected="selected"></option>
        <option VALUE="abc"> ABC</option>
        <option VALUE="def"> def</option>
        <option VALUE="hij"> hij</option>   
    </select>
    <INPUT TYPE="submit" name="submit" />
</form>



	
</body>

</html>