<?php

/*
 * Qui si mettono i valori che potrebbero cambiare per
 * adeguarsi ai cambiamenti dell'ambiente host.
 */

// Parametri MySQL
define ("DB_HOST","localhost");
define ("DB_NAME","db-italfrutta");
define ("DB_USER","root");
define ("DB_PASS","");

?>
