<?php

/*connessione al databse Italfrutta*/
$db = mysql_connect("localhost","root")or die("Connessione non riuscita: ".mysql_error());
  // echo ("Connesso con successo");
mysql_select_db("db-italfrutta", $db) or die("Errore nella selezione del database"); 

?>
