<html>
<title>Cancellazione Prodotto</title>
    <body>

<style type="text/css">
.style1 {
	text-align: center;
}
.style3 {
	font-family: Calibri;
	font-size: x-large;
	font-style: italic;
	font-weight: bold;
	font-variant: small-caps;
	text-align: center;
}
</style>
<link href="Style.css" rel="stylesheet" type="text/css" />

<table style="width: 25%">
	<tr>
		<td style="width: 324px; height: 123px;"><img src="Risorse/ItalfruttaL2.jpg" /></td>
		<td class="style1" style="height: 123px" colspan="2"><span class="TestoTitoli">ItalFrutta <br/>Cancellazione</span></td>
	</tr>

	<tr class="TestoTitoli">
		<td colspan="3" class="style1">Inserire il Codice del Prodotto da Cancellare:<br/><br/></td>
	</tr>
	<tr>
		<td class="style3">Cod. Prodotto</td>
		<td class="style1">
		<form method="post">
			<input name="CodProd" type="text" />
                        <input name="id" type="hidden" value='Cliente'>
		</td>
		<td class="style1"><input name="Canc" type="Submit" value="Cancella"/></form></td>
	</tr>
</table>


 <?
 include("connessione.php");
 
  if (isset($_POST['Canc']))
                            {
                              if (isset($_POST['CodProd'])) $CancProd=$_POST['CodProd'];
                              $sqlCanc=mysql_query("UPDATE prodotto SET Cancellazione=1 WHERE CodProd=$CancProd");
                             } 
                            //if ($sqlCanc) echo "Prodotto Cancellato";
 
 $sqlSP = mysql_query("SELECT ordine.CodOrd, ordine.Codice, ordine.FP, cliente.NomeCliente, nomeprod.NomeProd, 
        prodotto.Commenti, prodotto.Colli, prodotto.Stive, pezzatura.TipoPez, lavorazione.TipoLav, prodotto.Colore,
        ordine.OraPartenza, pallet.TipoPallet,imballo.TipoImballo, prodotto.CodProd, prodotto.Cancellazione 
      FROM ordine,cliente,nomeprod,prodotto,pezzatura,lavorazione,pallet,imballo
        WHERE ordine.CodCliente=cliente.codCliente
            AND prodotto.CodOrd=ordine.CodOrd
            AND prodotto.CodNP=nomeprod.CodNP
            AND prodotto.CodPez=pezzatura.CodPez 
            AND prodotto.CodLav=lavorazione.CodLav
            AND prodotto.CodPallet=pallet.CodPallet 
            AND prodotto.CodImb=imballo.CodImb  
            AND prodotto.Cancellazione < 001
        ORDER BY ordine.OraPartenza,ordine.Codice DESC");?>

</br></br>
<table style="width: 100%" class="style2">
	<tr>
		<td style="width: 324px">&nbsp;</td>
		<td class="style1"><span class="TestoTitoli">ItalFrutta - Tabella ordini 
		lavorazione</span></td>
	</tr>
	<tr>
		<td colspan="2">&nbsp;</td>
	</tr>
	<tr>
		<td colspan="2">		
        
        <table cellspacing="1" class="TabelleOrdini" style="width: 100%">
			<tr class="TestoPiccolo">
                                <td class="TabelleOrdini"><font size="4"><b>Prodotto da Cancellare</b></font></td>
				<td class="TabelleOrdini">N. Ordine</td>
                                <td class="TabelleOrdini">F.P.</td>
				<td class="TabelleOrdini">Cliente</td>
				<td class="TabelleOrdini">Prodotto</td>
				<td class="TabelleOrdini">Pez.</td>
				<td class="TabelleOrdini">Lavorazione</td>
				<td class="TabelleOrdini">Commenti</td>
				<td class="TabelleOrdini">T. Pallet</td>
				<td class="TabelleOrdini">Imballo</td>
				<td class="TabelleOrdini">Colli</td>
				<td class="TabelleOrdini">Stive</td>
				<td class="TabelleOrdini">Ora Part.</td>
				

			</tr>
                        
                        <? while ($rigaSP =  mysql_fetch_array($sqlSP,MYSQL_ASSOC)){   ?> 
                        
                        <tr class="<?=$rigaSP['Colore']?>" >
                                <td class="TabelleOrdini"><font size="6"><b><?echo $rigaSP['CodProd'];?></b></font></td>
				<td class="TabelleOrdini"><?echo $rigaSP['Codice'];?></td>
                                <td class="TabelleOrdini"><?echo $rigaSP['FP'];?></td>
				<td class="TabelleOrdini"><?echo $rigaSP['NomeCliente'];?></td>
				<td class="TabelleOrdini"><?echo $rigaSP['NomeProd'];?></td>
				<td class="TabelleOrdini"><?echo $rigaSP['TipoPez'];?></td>
				<td class="TabelleOrdini"><?echo $rigaSP['TipoLav'];?></td>
				<td class="TabelleOrdini"><?echo $rigaSP['Commenti'];?></td>
				<td class="TabelleOrdini"><?echo $rigaSP['TipoPallet'];?></td>
				<td class="TabelleOrdini"><?echo $rigaSP['TipoImballo'];?></td>
				<td class="TabelleOrdini"><?echo $rigaSP['Colli'];?></td>
				<td class="TabelleOrdini"><?echo $rigaSP['Stive']; ?></td>
				<td class="TabelleOrdini"><?echo $rigaSP['OraPartenza'];?></td>
				
			</tr>
                            <?}?>
		</table>
		
		</td>
	</tr>		
	</table>
        
</body>
</html>