<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>ItalFrutta - Modulo Anagrafica</title>
<style type="text/css">
.TestoTitoli {
	font-family: Calibri;
	font-size: x-large;
	font-style: italic;
	font-weight: bold;
	font-variant: small-caps;
}
.Testo {
	font-family: Calibri;
	font-size: large;
	font-weight: bold;
	font-style: italic;
}
.style2 {
	border-collapse: collapse;
	border: 1px solid #000000;
}
.Menu {
	ul: ;
	font-family: Calibri;

}

.style3 {
	border-right-width: 0;
	border-bottom-width: 0;
	border-left-color: #C0C0C0;
	border-left-width: 0;
	border-top-color: #C0C0C0;
	border-top-width: 0;
}

</style>
<link href="Style.css" rel="stylesheet" type="text/css" />
</head>

<body style="margin: 0">

<table style="width: 100%" class="style2">
	<tr>
		<td>
		        
        <table cellspacing="1" class="style3" style="width: 100%">
			<tr class="TitoliTab">
				<td class="TabelleOrdini" width="50px">Stato</td>
				<td class="TabelleOrdini" width="50px">Ora</td>
				<td class="TabelleOrdini" width="150px">Vettore</td>
				<td class="TabelleOrdini" width="150px">Portata</td>
				<td class="TabelleOrdini" width="150px">Nome</td>
				<td class="TabelleOrdini" width="150px">Note</td>
				<td class="TabelleOrdini" width="50px">Tel.</td>
				<td class="TabelleOrdini" width="50px">Arr.</td>
			</tr>
			<tr>
				<td class="TabelleOrdini" width="50" height="26">
				<img alt="Presa Visione" height="26" src="Rosso-Blu.jpg" width="50" /></td>
				<td class="TestoInterno" width="50px" rowspan="2">&nbsp;</td>
				<td class="TestoInterno" width="150px" rowspan="2">&nbsp;</td>
				<td class="TestoInterno" width="150px" rowspan="2">&nbsp;</td>
				<td class="TestoInterno" width="150px" rowspan="2">&nbsp;</td>
				<td class="TestoInterno" width="150px" rowspan="2">&nbsp;</td>
				<td class="TestoInterno" width="50px" rowspan="2">&nbsp;</td>
				<td class="TestoInterno" width="50px" rowspan="2">&nbsp;</td>
			</tr>
			<tr>
				<td class="TabelleOrdini">
				<img alt="Completato" height="26" src="VerdeT.jpg" width="50" /></td>
			</tr>

		</table>
		
		</td>
	</tr>		
	</table>

</body>

</html>
