<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Conferma Inserimento</title>
<style type="text/css">
.style1 {
	border: 1px solid #000000;
}
</style>
<link href="Style.css" rel="stylesheet" type="text/css" />
</head>

<body style="margin: 0">

	

<table cellspacing="1" class="style1" style="width: 350px">
	<tr>
		<td class="BordoTabella"><span class="TestoTitoli">Dato inserito correttamente</span></td>
	</tr>
</table>

	

</body>

</html>
