<html>
    <body>
<?php

include("connessione.php");  

 $sqlSP = mysql_query("SELECT DISTINCT (prodotto.CodProd), ordine.CodOrd, ordine.Codice, ordine.FP, cliente.NomeCliente, nomeprod.NomeProd, 
        prodotto.Commenti, prodotto.Colli, prodotto.Stive, pezzatura.TipoPez, lavorazione.TipoLav, 
        ordine.OraPartenza, pallet.TipoPallet,imballo.TipoImballo, prodotto.Colore, prodotto.CodProd  
      FROM ordine,cliente,nomeprod,prodotto,pezzatura,lavorazione,pallet,imballo
        WHERE ordine.CodCliente=cliente.codCliente
            AND prodotto.CodOrd=ordine.CodOrd
            AND prodotto.CodNP=nomeprod.CodNP
            AND prodotto.CodPez=pezzatura.CodPez 
            AND prodotto.CodLav=lavorazione.CodLav
            AND prodotto.CodPallet=pallet.CodPallet 
            AND prodotto.CodImb=imballo.CodImb         
        ORDER BY ordine.OraPartenza,ordine.Codice DESC");
$i=0;
 while ($rigaSP =  mysql_fetch_array($sqlSP,MYSQL_ASSOC)){ 
                        $i++;
                        echo "<b>";
                        echo $i;
                        echo "</b></br>";
                         $IDProd=$rigaSP['CodProd'];
                         echo $IDProd;
                        
                        if (isset($_POST['bottone']) && ($IDProd == $_POST['IDRiga'])) 
                                    $colore= $_POST['bottone'];
                        else $colore=$FondoRiga;?>

			
                        <form method='post'>
                        
                  
		           <? 
                           echo $rigaSP['CodOrd']; echo "</br>";
                            echo $rigaSP['Codice']; echo "</br>";
                            //echo $rigaSP['FP']; echo "</br>";
                            echo $rigaSP['NomeCliente'];echo "</br>";
                            echo $rigaSP['NomeProd'];echo "<b>";
                            echo $rigaSP['CodProd'];echo "</br></b>";
                            //echo $rigaSP['TipoPez'];echo "</br>";
                            //echo $rigaSP['TipoLav'];echo "</br>"; 
                            echo $rigaSP['Commenti'];echo "</br>";
                            //echo $rigaSP['TipoPallet'];echo "</br>";
                            //echo $rigaSP['TipoImballo'];echo "</br>";
			    //echo $rigaSP['Colli'];echo "</br>";
                            //echo $rigaSP['Stive'];echo "</br>";
                            echo $rigaSP['OraPartenza'];echo "</br>";?>
                         </form>   
		<?} echo "$i";?>
</body>
</html>
