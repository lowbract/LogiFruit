  <?        
    include("connessione.php");  
  
    if (isset($_POST['Ordine'])) $CodOrdine=$_POST['Ordine'];
    if (isset($_POST['FP'])) $FP=$_POST['FP'];
    if (isset($_POST['Cliente'])) $CodCliente=$_POST['Cliente']; 
    if (isset($_POST['Prodotto'])) $Prodotto=$_POST['Prodotto'];
    if (isset($_POST['Pezzatura'])) $Pezzatura=$_POST['Pezzatura'];
    if (isset($_POST['Lavorazione'])) $Lavorazione= $_POST['Lavorazione'];
    if (isset($_POST['Commento'])) $Commento=$_POST['Commento'];
    if (isset($_POST['Pallet'])) $Pallet=$_POST['Pallet'];
    if (isset($_POST['Imballo'])) $Imballo=$_POST['Imballo'];
    if (isset($_POST['Colli'])) $Colli=$_POST['Colli'];
    if (isset($_POST['Stive'])) $Stive=$_POST['Stive'];
    if (isset($_POST['OraP'])) $OraP=$_POST['OraP'];
    $FondoRiga= 'FondoRosso';
    
    $data= date("Y-m-d");
    
    
    
    /*----Inserimento in ordine e prodotto------- */
     
    
    if (isset($_POST['Modifica'])) { 
    
       $sqlOrd = mysql_query("SELECT ordine.CodOrd, ordine.Codice, ordine.data, ordine.OraPartenza From ordine");
        if ($sqlOrd) echo "<br> Select andata";
            while ($rigaOrd =  mysql_fetch_array($sqlOrd,MYSQL_ASSOC)){ 
                echo"<br> sono nel while";
                if (($CodOrdine==$rigaOrd['Codice']) && ($data==$rigaOrd['data'])  && ($OraP==$rigaOrd['OraP']) && ($FP==$rigaOrd['FP']))
                {
                    echo "<br> sono nel if";
                    $insertProdotto = "INSERT prodotto SET CodNP=$Prodotto, Colli=$Colli, Stive=$Stive, Commenti='$Commento', CodLav=$Lavorazione, CodPez=$Pezzatura, CodImb=$Imballo, CodPallet=$Pallet, CodOrd=$rigaOrd[CodOrd], Colore='$FondoRiga'"; 
                 
                    $queryProd = mysql_query($insertProdotto);
                    echo ("<br>Risultato query PRODOTTO= ".$queryProd);
                     if($queryProd) 
                        echo("<br>Dato Inserimento Correttamente"); 
                        else
                        echo("<br>Inserimento fallito");     
                        break;
                }
                        
            else{
                echo "<br> sono nell'else"; 
                 $insertOrdine = "INSERT ordine SET Codice=$CodOrdine, FP='$FP', data='$data', OraPartenza='$OraP', CodCliente=$CodCliente";
                 $queryOrd = mysql_query($insertOrdine);
                 echo ("<br>Risultato query ORDINE= ".$queryOrd);
                 if($queryOrd) 
                   echo("<br>Dato Inserimento Correttamente"); 
                 else
                 echo("<br>Inserimento fallito"); 
                 
                 $idOrd= mysql_insert_id();
                 echo "<br>". $idOrd;
                 
                 $insertProdotto = "INSERT prodotto SET CodNP=$Prodotto, Colli=$Colli, Stive=$Stive, Commenti='$Commento', CodLav=$Lavorazione, CodPez=$Pezzatura, CodImb=$Imballo, CodPallet=$Pallet, CodOrd=$idOrd, Colore='$FondoRiga'";
                  
                 $queryProd = mysql_query($insertProdotto);
                   echo ("<br>Risultato query PRODOTTO= ".$queryProd);
                 if($queryProd) 
                   echo("<br>Dato Inserimento Correttamente"); 
                 else
                 echo("<br>Inserimento fallito");
                 break;
                }
                
              }
                
                } 
?>