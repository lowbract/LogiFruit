<html>
    <body
<head>
<style type="text/css">
</style>
</head>      
<link href="Style.css" rel="stylesheet" type="text/css" />
<?php

include("connessione.php");  

$sql = mysql_query("SELECT NomeCliente FROM cliente ORDER BY NomeCliente");

//if ($sql) echo "ok";
?>
<table border='1' color='BLACK' style="width:50%">
<form method="post" action="trasporto.php">
    <tr class="TestoPiccolo" border="1">    
        <td>
        Inserire N. Ordine a cui assegnare un Trasporto: 
        </td>
        <td></td>
        
    <tr>
    <tr> 
        <td>
        <input name="NumOrdine" type="text">
        </td>
     <td><input name="OrdTrasp" type="Submit" value="Inserisci" />    </td>
    </tr>
</form> 
</table>
    <br/>  <br/>  <br/>  
</body>

</html>  

