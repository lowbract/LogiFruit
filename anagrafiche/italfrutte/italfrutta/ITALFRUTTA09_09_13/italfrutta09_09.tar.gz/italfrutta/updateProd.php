<?php
include("connessione.php");

 if (isset($_POST['Modifica']))   {     
     echo "modifica";
    if (isset($_POST['CodOrd'])) $CodOrd=$_POST['CodOrd'];
    if (isset($_POST['CodProd'])) $CodProd=$_POST['CodProd'];
    if (isset($_POST['Ordine'])) $CodOrdine=$_POST['Ordine'];
    if (isset($_POST['FP'])) $FP=$_POST['FP'];
    if (isset($_POST['Cliente'])) $CodCliente=$_POST['Cliente']; 
    if (isset($_POST['Prodotto'])) $Prodotto=$_POST['Prodotto'];
    if (isset($_POST['Pezzatura'])) $Pezzatura=$_POST['Pezzatura'];
    if (isset($_POST['Lavorazione'])) $Lavorazione= $_POST['Lavorazione'];
    if (isset($_POST['Commento'])) $Commento=$_POST['Commento'];
    if (isset($_POST['Pallet'])) $Pallet=$_POST['Pallet'];
    if (isset($_POST['Imballo'])) $Imballo=$_POST['Imballo'];
    if (isset($_POST['Colli'])) $Colli=$_POST['Colli'];
    if (isset($_POST['Stive'])) $Stive=$_POST['Stive'];
    if (isset($_POST['OraP'])) $OraP=$_POST['OraP'];
    $FondoRiga= 'FondoRosso';
    $CodOrd=$rigaSP['CodOrd'];
    echo $Colli; 
    echo $CodOrd;
    
    $data= date("Y-m-d");
    $sqlProva=  mysql_query("UPDATE ordine SET Codice=$CodOrdine");
   if ($sqlProva) echo "sql prova";
    $sqlUpdateOrd= mysql_query("UPDATE ordine SET Codice=$CodOrdine , FP='$FP', data='$data', OraPartenza='$OraP', CodCliente=$CodCliente WHERE CodOrd=$CodOrd_FromSelect");
            
    $sqlUpdateProd =mysql_query("UPDATE prodotto SET CodNP=$Prodotto, Colli=$Colli, Stive=$Stive, Commenti='$Commento', CodLav=$Lavorazione, CodPez=$Pezzatura, CodImb=$Imballo, CodPallet=$Pallet, CodOrd=$CodOrd, Colore='$FondoRiga' WHERE CodProd=$CodProd_FromSelect");
    
    echo $sqlUpdateOrd;
    echo $sqlUpdateProd;
    
    if ($sqlUpdateOrd) echo "ok Update Ordine!";
                            if ($sqlUpdateProd) echo "ok Update Prodotto!"; } 
                            //if ($sqlCanc) echo "Prodotto Cancellato";
?>
