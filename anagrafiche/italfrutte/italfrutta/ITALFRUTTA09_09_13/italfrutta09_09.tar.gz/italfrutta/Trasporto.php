<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Trasporti ItalFrutta</title>
<link href="Style.css" rel="stylesheet" type="text/css" />
</head>

<body style="margin: 0">

<table width="100%" cellpadding="0" cellspacing="0">
	<tr>
		<td>		
			<table style="width: 100%" class="BordoTabella2">
				<tr>
					<td style="width: 324px"><img src="Risorse/ItalfruttaL2.jpg" /></td>
					<td class="style1"><span class="TestoTitoli">ItalFrutta - tabella ordini lavorazione</span></td>
				</tr>
			</table>
			<br/>
			<table width="100%" cellpadding="0" cellspacing="0">
				<tr>
					<td width="45%" valign="top"><? include("Trasporti.php"); ?></td>
					<td width="55%"><? include("lavorazione.php"); ?></td>
				</tr>
			</table>
		</td>
	</tr>
</table>

</body>

</html>
