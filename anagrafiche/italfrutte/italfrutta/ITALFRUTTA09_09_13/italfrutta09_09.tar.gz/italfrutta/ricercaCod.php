<html>
    <body>

<style type="text/css">
.style1 {
	text-align: center;
}
.style3 {
	font-family: Calibri;
	font-size: x-large;
	font-style: italic;
	font-weight: bold;
	font-variant: small-caps;
	text-align: center;
}
</style>
<link href="Style.css" rel="stylesheet" type="text/css" />

<table style="width: 25%">
	<tr>
		<td style="width: 324px; height: 123px;"><img src="Risorse/ItalfruttaL2.jpg" /></td>
		<td class="style1" style="height: 123px" colspan="2"><span class="TestoTitoli">ItalFrutta <br/>Modifica</span></td>
	</tr>

	<tr class="TestoTitoli">
		<td colspan="3" class="style1">Inserire il Codice del Prodotto da Modificare:<br/><br/></td>
	</tr>
	<tr>
		<td class="style3">Cod. Prodotto</td>
		<td class="style1">
		<form method="post" action="modificaprodotto.php" >
			<input name="CodProd" type="text" />
		</td>
		<td class="style1"><input name="Ricerca" type="Submit" value="Ricerca"/></form></td>
	</tr>
</table>
    </body>
</html>
