<?php

if (isset($_POST['Button1'])){

    echo $_POST['Cliente'];
    echo $_POST['Pezzatura'];
    echo $_POST['Lavorazione'];
}
?>
