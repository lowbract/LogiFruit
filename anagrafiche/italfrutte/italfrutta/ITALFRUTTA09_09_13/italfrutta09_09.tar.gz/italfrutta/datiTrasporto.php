<html>
		
<head>
<title>Inserimento Trasporto</title>
<style type="text/css">
</style>
</head>

<body>
<? 
    
include("connessione.php");  


if (isset($_POST['OrdTrasp'])){
    
    if (isset($_POST['NumOrdine'])) $NumOrdine=$_POST['NumOrdine'];
}

?>

     
<link href="Style.css" rel="stylesheet" type="text/css" />

<form method="post" action="trasporto.php">
<table border='1' color='BLACK'>
<tr class="TestoPiccolo">
    <td>
        N.Ordine
    </td>    
    <td>
        Cliente
    </td> 
    <td>
       Vettore
    </td>    
    <td style="width: 75px">
       Portata
    </td> 
    <td>
       Nome e Cognome
    </td> 
    <td>
        Note
    </td>
    <td>
        Imballo
    </td>
    <td>
        Misura
    </td>   
    <td style="width: 30px">
        Arr.
    </td>    
    <td style="width: 30px">
       Cro.
    </td> 
    
</tr>

 <? $sqlCliente = mysql_query("SELECT ordine.Codice FROM ordine WHERE Codice=$NumOrdine");
         
while ($rigaOrdini =  mysql_fetch_array($sqlCliente,MYSQL_ASSOC)) {?>

<tr>
<!cella per la SELECT del nome ORDINE------------------>    

<td>
    
<?
          echo $NumOrdine; 
          echo "<input name=NumOrdine type=hidden value=$NumOrdine>\n";
    ?>

</td>

<!cella per la SELECT del nome Cliente------------------->
<td>
<?$sqlCliente = mysql_query("SELECT ordine.Codice,cliente.NomeCliente FROM ordine,cliente WHERE ordine.CodCliente=cliente.CodCliente AND ordine.CodOrd=$NumOrdine");?>
   
   <? $rigaCliente =  mysql_fetch_array($sqlCliente,MYSQL_ASSOC);
    echo $rigaCliente['NomeCliente'];
    $Cliente=$rigaCliente['NomeCliente'];
    echo "<input name=NumOrdine type=hidden value=$Cliente>\n";
   ?>
  
</td>
 

<!cella per la SELECT del VETTORE---------->
<td>
     
 <?
    $sqlVett = mysql_query("SELECT CodVett,NomeVettore FROM vettore ORDER BY NomeVettore");?>
    <select name="Vettore" style="width: 150px">
    <option value=""></option>
    <? while ($rigaSP =  mysql_fetch_array($sqlVett,MYSQL_ASSOC)){
    echo "<option value=\"".$rigaSP['CodVett']."\">".$rigaSP['NomeVettore']."</option>";
    }?>
    </select>
     
 </td>

<!cella per l'INSERIMENTO della Portata------------------>
<td style="width: 75px">

    <input name='Portata' type='number'>

</td>


<!cella per la SELECT del NOME E COGNOME dell'autista----------------->
<td>   
    
<?
    $sqlAut = mysql_query("SELECT CodAut,Nome,Cognome FROM autista ORDER BY Nome, Cognome");?>
    <select name="Autista" style="width: 150px">
    <option value=""></option>
    <? while ($rigaSP =  mysql_fetch_array($sqlAut,MYSQL_ASSOC)){
    echo "<option value=\"".$rigaSP['CodAut']."\">".$rigaSP['Nome'].$rigaSP['Cognome']."</option>";
    }?>
    </select>
     
</td>

<!cella per le NOTE------>
<td>    
   
    <input name='Note' type='text'>
</td>

<!cella per le Imballo------>
<td>    
  <?
    $query="SELECT imballo.TipoImballo FROM imballo,prodotto WHERE prodotto.CodImb=imballo.CodImb AND prodotto.CodOrd=$NumOrdine";
    //print_r($query);
    $sqlImballo = mysql_query($query);
    $rigaImballo =  mysql_fetch_array($sqlImballo,MYSQL_ASSOC);
    echo $rigaImballo['TipoImballo'];
    $Imballo=$rigaImballo['TipoImballo'];
    echo "<input name=NumOrdine type=hidden value=$Imballo>\n";
   ?>
</td>


<!cella per ARRIVATO---------------->
<td 'width: 100px' style="width: 30px">
    <input name='Arrivato' type='text'>
 </td>
 
 <!cella per la CRONOLOGIA---------------->
<td style="width: 30px">   
    
    <input name="Cronologia" type="text">
    
</td>


           </tr> <?}?>
</table>
</br>     
<input name="InserTrasp" type="Submit" value="Inserisci" />    
</form> 

  
</body>

</html>  
  
  
 
